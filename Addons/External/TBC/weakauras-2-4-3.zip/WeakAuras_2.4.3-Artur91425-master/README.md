# WeakAuras Backport to 2.4.3 TBC

Attempting to backport current weakauras to TBC for use on the LH server

On 26.03.2020 its best work repo of Wa.

I am not the author of this backport.
I just uploaded it to the github because the author is too lazy to create his own repository.
But I have a connection with the author.

Works:

Aura check (except for checking the remaining aura ...)

Checking cooldowns (there are some incorrectly working spells, for example mangle druids)

Battle log check

Can Spell Use check


The rest works partially, but you can always write a report, or (and it will be better) to fix it yourself.


## How To

Very little of the useage/interface should be changed from the legitimate versions of WeakAuras, check them out


## Credits - WeakAuras and Resources used to emulate updates that were added to the wow api

This backport is created by Artur91425 [https://github.com/Artur91425]

And also based on developments:

Numielle [https://github.com/Numielle] for ActionButtonGlow

Schaka [https://www.reddit.com/r/wowservers/comments/4e9yy1/tbc_bufflib_an_addon_to_share_spell_timers] for BuffLib
