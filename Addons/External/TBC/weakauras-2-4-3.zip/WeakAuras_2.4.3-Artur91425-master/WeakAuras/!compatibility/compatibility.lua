--[[
	UnitAlternatePowerInfo
	UnitAlternatePowerTextureInfo
	GetRealEclipseDirection
--]]
function wipe(t)
	if type(t) ~= "table" then
		error(("bad argument #1 to 'wipe' (table expected, got %s)"):format(t and type(t) or "no value"), 2)
	end
	for k in pairs(t) do
		t[k] = nil
	end
  return t
end
table.wipe = wipe

-----------
-- print --
-----------
do
	local LOCAL_ToStringAllTemp = {};
	function tostringall(...)
    local n = select('#', ...);
    -- Simple versions for common argument counts
    if (n == 1) then
			return tostring(...);
			elseif (n == 2) then
			local a, b = ...;
			return tostring(a), tostring(b);
			elseif (n == 3) then
			local a, b, c = ...;
			return tostring(a), tostring(b), tostring(c);
			elseif (n == 0) then
			return;
		end
		
    local needfix;
    for i = 1, n do
			local v = select(i, ...);
			if (type(v) ~= "string") then
				needfix = i;
				break;
			end
		end
    if (not needfix) then return ...; end
		
    wipe(LOCAL_ToStringAllTemp);
    for i = 1, needfix - 1 do
			LOCAL_ToStringAllTemp[i] = select(i, ...);
		end
    for i = needfix, n do
			LOCAL_ToStringAllTemp[i] = tostring(select(i, ...));
		end
    return unpack(LOCAL_ToStringAllTemp);
	end
	
	local LOCAL_PrintHandler =
	function(...)
		DEFAULT_CHAT_FRAME:AddMessage(strjoin(" ", tostringall(...)));
	end
	
	function setprinthandler(func)
    if (type(func) ~= "function") then
			error("Invalid print handler");
			else
			LOCAL_PrintHandler = func;
		end
	end
	
	function getprinthandler() return LOCAL_PrintHandler; end
	
	local geterrorhandler = geterrorhandler;
	local forceinsecure = forceinsecure;
	local pcall = pcall;
	local securecall = securecall;
	
	local function print_inner(...)
    --forceinsecure();
    local ok, err = pcall(LOCAL_PrintHandler, ...);
    if (not ok) then
			local func = geterrorhandler();
			func(err);
		end
	end
	
	function print(...)
    securecall(pcall, print_inner, ...);
	end
	SlashCmdList["PRINT"] = print
	SLASH_PRINT1 = "/print"
end

function UnitAura(unit, indexOrName, rank, filter)
	--[[
	local aura_index, aura_name, aura_type
	if type(indexOrName) ~= "number" then
		aura_name = indexOrName
	else
		aura_index = indexOrName
	end
	if not filter and rank then
		if type(rank) ~= "number" and rank:find("[HELPFUL,HARMFUL,PLAYER,RAID,CANCELABLE,NOT_CANCELABLE]") then
			filter = rank
			rank = nil
		else
			filter = "HELPFUL" -- default value https://wowwiki.fandom.com/wiki/API_UnitAura
		end
	end
	
	if aura_name then
		local i = 1
    while true do
      name, r, icon, count, duration, expirationTime = UnitBuff(unit, i, filter)
			
			i = i + 1
		end
	end
	--]]
	
  local newrank = (rank and rank:gsub("|HELPFUL", ""):gsub("HELPFUL|", ""):gsub("HELPFUL", ""):gsub("|HARMFUL", ""):gsub("HARMFUL|", ""):gsub("HARMFUL", "")) or nil;
  local newfilter = (filter and filter:gsub("|HELPFUL", ""):gsub("HELPFUL|", ""):gsub("HELPFUL", ""):gsub("|HARMFUL", ""):gsub("HARMFUL|", ""):gsub("HARMFUL", "")) or nil;
	
  if ((filter and filter:find("HARMFUL")) or ((rank and rank:find("HARMFUL")) and filter == nil)) then
    debuffType = "HARMFUL";
		elseif ((filter and filter:find("HELPFUL")) or ((rank and rank:find("HARMFUL")) and filter == nil)) then
    debuffType = "HELPFUL";
		else
    debuffType = nil;
	end
  
  local x;
	
  if (debuffType == "HELPFUL" or debuffType == nil) then
    local name, r, icon, count, duration, expirationTime = UnitBuff(unit, 1, newfilter);
    x = 1;
    while (name ~= nil) do
      if (name == indexOrName and (rank == nil or rank:find("HARMFUL") or rank:find("HELPFUL") or rank == r)) then
        return name, r, icon, count, debuffType, duration, GetTime() + (expirationTime or 0)
			end
      x = x + 1;
      name, r, icon, count, duration, expirationTime = UnitBuff(unit, x, newfilter);
		end
	end
	
  if (debuffType == "HARMFUL" or debuffType == nil) then
    local name, r, icon, count, duration, expirationTime = UnitDebuff(unit, 1, newfilter);
    x = 1;
    while (name ~= nil) do
      if (name == indexOrName and (rank == nil or rank:find("HARMFUL") or rank:find("HELPFUL") or rank == r)) then
        return name, r, icon, count, debuffType, duration, GetTime() + (expirationTime or 0)
			end
      x = x + 1;
      name, r, icon, count, duration, expirationTime = UnitDebuff(unit, x, newfilter);
		end
	end
	
  return nil;
end

function UnitInVehicle(unit)
	return false
end

function UnitPower(unit, powerType)
	return UnitMana(unit, powerType)
end

function UnitPowerMax(unit, powerType)
	return UnitManaMax(unit, powerType)
end

local hooks = {}

local function SpellID_to_SpellName(spell)
	if type(spell) == "number" then
		return GetSpellInfo(spell)
	else
		if tonumber(spell) then
			return GetSpellInfo(spell)
		else
			return spell
		end
	end
	return
end

hooks.GetSpellCooldown = GetSpellCooldown
function GetSpellCooldown(spell, booktype)
	if booktype and (booktype == BOOKTYPE_SPELL or booktype == BOOKTYPE_PET) then
		return hooks.GetSpellCooldown(spell, booktype) -- вызываем оригинал
	else
		spell = SpellID_to_SpellName(spell)
		return hooks.GetSpellCooldown(spell) -- вызываем оригинал
	end
end

hooks.IsUsableSpell = IsUsableSpell
function IsUsableSpell(spell, booktype)
	if booktype and (booktype == BOOKTYPE_SPELL or booktype == BOOKTYPE_PET) then
		return hooks.IsUsableSpell(spell, booktype) -- вызываем оригинал
	else
		spell = SpellID_to_SpellName(spell)
		return hooks.IsUsableSpell(spell) -- вызываем оригинал
	end
end

hooks.IsSpellInRange = IsSpellInRange
function IsSpellInRange(spell, booktype, unit)
	if booktype then
		if booktype == BOOKTYPE_SPELL or booktype == BOOKTYPE_PET then
			return hooks.IsSpellInRange(spell, booktype, unit) -- вызываем оригинал
		else
			unit = booktype
			spell = SpellID_to_SpellName(spell)
			return hooks.IsSpellInRange(spell, unit) -- вызываем оригинал
		end
	else
		spell = SpellID_to_SpellName(spell)
		return hooks.IsSpellInRange(spell) -- вызываем оригинал
	end
end

function GetSpellBookID(spellID, booktype)
	booktype = booktype or BOOKTYPE_SPELL
	local book_id = 1
	while true do
		local link = GetSpellLink(book_id, booktype)
		if not link then return end
		local id = tonumber(link:match('H.-:(%d+)|h'))
		if id == spellID then
		  return book_id
		end
		book_id = book_id + 1
	end
end

function PrintTab(obj, max_depth, level, meta_level)
	if not obj or obj == "" then
		print('Root = nil')
		return
	end
	if not level then level = 0 end
	if not max_depth then max_depth = 299 end
	if level == 0 then
		obj = {Root = obj}
	end
	
	local Table_stack
	if not Table_stack then
		Table_stack = {}
	end
	local inset = strrep('   ', level)
	inset = '\19'..inset
	local close_flag = false
	local meta_flag = false
	for m_key, m_value in pairs(obj) do
		key = m_key
		value = m_value
		if type(key) == 'table' then
			key = 'table_key'
			elseif type(key) == 'function' then
			key = 'function'
			elseif type(key) == 'userdata' then
			key = 'userdata'
		end
		if type(value) == 'table' then
			if not Table_stack[value] and (level < max_depth) then
				print(inset..'['..key..'] = {')
				Table_stack[value] = true
				PrintTab(value, max_depth, level+1, obj, meta_level)
				else
				close_flag = true
				print(inset..'['..key..'] = {...}')
			end
			elseif type(value) == 'function' then
			print(inset..'['..key..'] = function')
			elseif type(value) == 'userdata' then
			local user_data = 'userdata'
			if pcall(function() obj:GetName() end) then
				user_data = obj:GetName() or ''
			end
			print(inset..'['..key..'] = '..user_data)
			elseif type(value) == 'boolean' then
			print(inset..'['..key..'] = '..tostring(value))
			else
			print(inset..'['..key..'] = '..value)
		end
	end
	local meta = getmetatable(obj)
	if meta and meta_level   then
		if not Table_stack[meta] and (level < max_depth) then
			print(inset..'[metatable] = {')
			Table_stack[meta] = true
			PrintTab(meta, max_depth, level+1, obj, meta_level)
			else
			meta_flag = true
			print(inset..'['..key..'] = {...}')
		end
	end
	if not close_flag and level > 0 then
		inset = strrep('   ', level-1)
		inset = '\19'..inset
		print(inset..'}')
	end
	if level == 0 then
		for k, v in pairs(Table_stack) do
			Table_stack[k] = nil
		end
		Table_stack = nil
	end
end
